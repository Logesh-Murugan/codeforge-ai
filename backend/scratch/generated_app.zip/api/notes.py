from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from core.security import get_current_user
from schemas import NoteCreate, Note
from models import Note as NoteModel
from db import get_db
from core.config import settings

notes_router = APIRouter(
    prefix='/notes',
    tags=['notes'],
)

@notes_router.post('/')
async def create_note(note: NoteCreate, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    note_obj = NoteModel(content=note.content, author_id=current_user.id)
    db.add(note_obj)
    await db.commit()
    await db.refresh(note_obj)
    return note_obj

@notes_router.get('/{id}')
async def get_note(id: int, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    note = await db.execute(select(NoteModel).where(NoteModel.id == id).where(NoteModel.author_id == current_user.id))
    note = note.scalars().first()
    if not note:
        raise HTTPException(
            status_code=404,
            detail='Note not found',
        )
    return note

@notes_router.get('/')
async def get_notes(db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    notes = await db.execute(select(NoteModel).where(NoteModel.author_id == current_user.id))
    notes = notes.scalars().all()
    return notes

@notes_router.put('/{id}')
async def update_note(id: int, note: NoteCreate, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    note_obj = await db.execute(select(NoteModel).where(NoteModel.id == id).where(NoteModel.author_id == current_user.id))
    note_obj = note_obj.scalars().first()
    if not note_obj:
        raise HTTPException(
            status_code=404,
            detail='Note not found',
        )
    note_obj.content = note.content
    db.add(note_obj)
    await db.commit()
    await db.refresh(note_obj)
    return note_obj

@notes_router.delete('/{id}')
async def delete_note(id: int, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    note = await db.execute(select(NoteModel).where(NoteModel.id == id).where(NoteModel.author_id == current_user.id))
    note = note.scalars().first()
    if not note:
        raise HTTPException(
            status_code=404,
            detail='Note not found',
        )
    await db.delete(note)
    await db.commit()
    return {'message': 'Note deleted successfully'}
